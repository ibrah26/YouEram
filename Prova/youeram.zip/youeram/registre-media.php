<?php include 'templates/header.php';?>


<body>
    <body>
        <div class="top-content">
        	<div class="inner-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-8 col-sm-offset-2 text">
                            <h1></h1>
                            <div class="description">
                            	<p>
	                            	
                            	</p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3 form-box">
                        	<div class="form-top">
                        		<div class="form-top-left">
                        			<h3>Carrega </h3>
                            		<p>Puja el teu contingut </p>
                        		</div>
                        		<div class="form-top-right">
                        			<i class="fa fa-lock"></i>
                        		</div>
                            </div>
    <div class="container">
        <div class="col-md-10">
            <form action="api/registre-media.php" method="post">
                <div class="col">
                    <input  type="text" class="form-control" name="titol" placeholder="titol">
                </div>
                <div class="col">
                    <input  type="text" class="form-control" name="descripcio" placeholder="descripció">
                </div>
                <div class="col">
                    <input  type="text" class="form-control" name="assignatura" placeholder="assignatura">
                </div>
                <div class="col">
                    <input  type="text" class="form-control" name="nomtreball" placeholder="nom treball">
                </div>
                <div class="col">
                    <input  type="number" class="form-control" name="any-entrada" placeholder="promocio">
                </div>
                <div class="col">
                    <input  type="number" class="form-control" name="curs" placeholder="curs">
                </div>
                <div class="col">
                    <input  type="text" class="form-control" name="url" placeholder="url">
                </div>


                <button type="submit" class="btn btn-default">Enviar</button>
            </form>
        </div>
    </div>
        <script src="js/jquery-1.11.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.backstretch.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
