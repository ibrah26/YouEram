<?php
/* Creació de dades per la connexio de la bdd del phpMyadmin*/
$conex = array('host' => 'localhost',
    'user' => 'root',
    'pass' => 'root',
    'db' => 'youeram'
);
